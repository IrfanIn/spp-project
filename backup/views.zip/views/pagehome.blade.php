<!DOCTYPE html>
<html lang="en">

<head>
    <title>Layout Web</title>
    <link rel="stylesheet" href="/css/mystyle.css">
</head>

<body>
    <div class="Section_top">
        <div class="content">
            <h1>Oya <span>Developer</span></h1>
            <a href="/pagehome">ENTER</a>
            <form method="GET">
        </div>
    </div>
    <audio controls autoplay>
        <source src="/audio/music1.mp3"></audio>
</body>

</html>
