<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400&family=Lato:wght@300&family=Poppins:wght@200&family=Rubik+Moonrocks&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.rtl.min.css"
        integrity="sha384-+4j30LffJ4tgIMrq9CwHvn0NjEvmuDCOfk6Rpg2xg7zgOxWWtLtozDEEVvBPgHqE" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    {{-- <link rel="stylesheet" href="{{ asset('css/app.css') }}"> --}}
    <title>Login</title>
</head>

<body>
    <nav class="mb-2 navbar">
        <div class="container-lg">
        <a class="navbar-brand"></a>
        <a button class="btn btn-outline-success" href="/pagehome" type="submit"><i class="bi bi-arrow-left-square"></i></a>
        </div>
    </nav>

    {{-- login --}}
    <div
        class="container w-100 justify-content-center d-flex vh-100 h-screen align-items-center
        {{ !Request::is('login') ? 'd-none' : '' }}">

        {{-- <form action="/login" method="post" class="flex items-center w-1/3 h-96 shadow-lg p-4 border-2 flex-col">
            @csrf
            <h3 class="text-slate-700 text-2xl uppercase font-inter mb-8">login</h3>
            <input type="email" placeholder="email" required class="border-2 border-sky-400 w-full py-2 pl-4 rounded-full my-2" name="email">
            <input type="password" placeholder="password" required class="border-2 border-sky-400 w-full py-2 pl-4 rounded-full my-2" name="password">
            <button type="submit" class="bg-lime-400 hover:bg-lime-500 w-full py-2 pl-4 rounded-full my-2">submit</button>
            <a href="/" class="self-start mx-4">back</a>
        </form> --}}

        <div class="d-flex align-items-center h-75 w-75 gap-2 bg-light position-relative">
            <div class="bg-black h-100 w-50 d-flex align-items-center justify-content-center flex-column">
                <h3 class="text-white text-uppercase">Kelas Kursus</h3>
                <img src="/img/class.jpg" height="190" style="transform: scaleX(-1)">
                <div class="position-absolute bottom-0 p-4 d-flex justify-content-center gap-4 w-50">
                    <a href="" class="text-light"><i class="fa-brands fa-twitter"></i></a>
                    <a href="" class="text-light"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="" class="text-light"><i class="fa-brands fa-instagram"></i></a>
                </div>
            </div>
            <div class="h-100 d-flex align-items-center w-50 mx-2">
                <form class="w-100" method="post" action="/login">
                    @csrf

                    @if (session()->has('error'))
                        <div class="alert alert-danger" role="alert">
                            <i class="fa-solid fa-info ms-2"></i>
                            {{ session('error') }}
                        </div>
                    @endif

                    @if (session()->has('created'))
                        <div class="alert alert-primary" role="alert">
                            <i class="fa-solid fa-info ms-2"></i>
                            {{ session('created') }}
                        </div>
                    @endif

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email</label>
                        <input type="ematil" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-4">Submit</button>
                    <a href="/daftar" class="">daftar <i class="fa-solid fa-arrow-left me-2"></i></a>
                </form>
            </div>
        </div>

    </div>

    {{-- daftar --}}
    <div
    
        class="container w-100 justify-content-center d-flex vh-100 h-screen align-items-center
    {{ !Request::is('daftar') ? 'd-none' : '' }}">

        @if (session()->has('error'))
            <p>{{ session('error') }}</p>
        @endif

        {{-- <form action="/daftar" method="post" class="flex items-center w-1/3 h-96 shadow-lg p-4 border-2 flex-col">
        @csrf
        <h3 class="text-slate-700 text-2xl uppercase font-inter mb-8">register</h3>
        <input type="text" placeholder="name" required
            class="border-2 border-sky-400 w-full py-2 pl-4 rounded-full my-2" name="name">
        <input type="email" placeholder="email" required
            class="border-2 border-sky-400 w-full py-2 pl-4 rounded-full my-2" name="email">
        <input type="password" placeholder="password" required
            class="border-2 border-sky-400 w-full py-2 pl-4 rounded-full my-2" name="password">
        <button type="submit"
            class="bg-lime-400 hover:bg-lime-500 w-full py-2 pl-4 rounded-full my-2">submit</button>
        <a href="/" class="self-start mx-4">back</a>
    </form> --}}

        <div class="d-flex align-items-center h-75 w-75 gap-2 bg-light position-relative">
            <div class="bg-black h-100 w-50 d-flex align-items-center justify-content-center flex-column">
                <h3 class="text-white text-uppercase">class kursus</h3>
                <img src="/img/class.jpg" height="190" style="transform: scaleX(-1)">
                <div class="position-absolute bottom-0 p-4 d-flex justify-content-center gap-4 w-50">
                    <a href="" class="text-light"><i class="fa-brands fa-twitter"></i></a>
                    <a href="" class="text-light"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="" class="text-light"><i class="fa-brands fa-instagram"></i></a>
                </div>
            </div>
            <div class="h-100 d-flex align-items-center w-50 mx-2">
                <form class="w-100" method="post" action="/daftar">
                    @csrf
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            name="name">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            name="email">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" name="password">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-4">Submit</button>
                    <a href="/login" class="">login <i class="fa-solid fa-arrow-left me-2"></i></a>
                </form>
            </div>
        </div>

    </div>

</body>

</html>
