<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
</head>

<body>

    <!-- header -->
    <div class="bg-primary" style="height: 10vh;">
        <!-- <img src="" alt=""> -->
        <nav class="mb-4 navbar navbar-expand-lg text-light navbar-light bg-dark">
            <div class="container-lg">
                <a class="navbar-brand text-light" href="/pagehome"><i class="fa-brands fa-bilibili"></i> Kursus Oya</a>
            </div>
            <div class="dropdown">
                <button class="btn btn-transparnt  bg-light navbar-light dropdown-toggle" type="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    Ari Yanto
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="/pagehome">Back Home</a></li>
                    <li><a class="dropdown-item" href="/login">Logout</a></li>
                </ul>
            </div>
    </div>
    </div>
    <div class="container-fluid" style="width: 95%; margin: auto;">

        <!-- dashboard -->
        <div class="px-2 py-4">
            <h3>Dashboard</h3>
            <hr class="border" style="width: 5rem; background-color: purple; height: .5rem;">
            <!-- dashboard -->
            <div class="dashboard-item row gap-4">
                <!-- dashboard item -->
                <div class="row gap-4">
                    <div class="col bg-light rounded border p-3">
                        <h5><i class="fa-solid fa-calendar"></i> Jadwal Pertemuan Bahasa</h5>
                        <p>pengelolaan jadwal pertemuan bahasa.</p>
                        <a href="/kelas-kursus" class="btn btn-primary float-end">Detail jadwal</a>
                    </div>
                    <div class="col bg-light rounded border p-3">
                        <h5><i class="fa-solid bi bi-check2"></i> Kehadiran Siswa</h5>
                        <p>pengelolaan jadwal kehadiran.</p>
                        <a href="" class="btn btn-primary float-end">Detail jadwal</a>
                    </div>
                    <div class="col bg-light rounded border p-3">
                        <h5><i class="bi bi-pie-chart-fill"></i> Data</h5>
                        <p>Data</p>
                        <a href="" class="btn btn-primary float-end">Detail jadwal</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
</body>

</html>
