<?php

namespace App\Http\Controllers;

use App\Models\kursus;
use Illuminate\Http\Request;

class KursusController extends Controller
{
    public function kursus(kursus $kursus, Request $request)
    {
        $filter = $kursus::where('jenis_kursus',$request->jenis)->get();
        return view('cadangan.kursus', [
            'kursus' => $filter
        ]);
    }
    public function index()
    {
        return view('layouts.kursus', [
            'kursus' => kursus::all()
        ]);
    }
}

